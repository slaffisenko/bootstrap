(function(){
	if(top != self){
		return
	}
	var version = 72;
	var production = true;
	var thisSrc = null
	var scripts = document.getElementsByTagName("script");
	Array.prototype.forEach.call(scripts,function(script){
		script.addEventListener('load',function(){
			if(thisSrc === null && script.src && script.src.indexOf('main_en.js')>0){
				thisSrc = script.src
				start()
			}
		})
	})
	var starttime = new Date().getTime()
	var lasttime = starttime
	var _log = []
	var report_logs = false
	var _profile = {}
	var _timeout = null
	var unittests = {};
	var was_error_on_unit_test = false;
	var make_unit_tests = function(only_errors){
		if(production) return;
		if(was_error_on_unit_test) return;
		var total_tests = 0;
		var pass_tests = 0;
		var fail_tests = 0;
		if(!only_errors) console.group('Unit test');
		for(var k in unittests){
			var mod = unittests[k];
			if(!only_errors) console.group('Test module: '+mod.module);
			mod.tests.forEach(function(test){
				try{
					total_tests++;
					var rez = test[1].call(mod.window);
					if(rez===true){
						pass_tests++;
						if(!only_errors) console.log("%s: PASS",test[0]);
					}
					else{
						fail_tests++;
						console.error("Module %s - %s: FAILED",mod.module,test[0]);
						was_error_on_unit_test = true;
						if(only_errors) alert('Unit test Module '+mod.module+' - '+test[0]);
					}
				}
				catch(e){
					console.error("Exception on unit test!",e);
					was_error_on_unit_test = true;
					fail_tests++;
					debugger;
				}
			})
			if(!only_errors) console.groupEnd('Test module: '+mod.module);
		}
		if(!only_errors || fail_tests>0){
			console[fail_tests>0?'error':'log']("Всего тестов %i, ошибок %s, прошедших %i",total_tests,fail_tests,pass_tests);
		}
		if(!only_errors) console.groupEnd('Unit test');
	}
	setInterval(function(){
		if('ktbt_debug' in window){
			report_logs = true
			delete window.ktbt_debug
			ktbt_debug();
		}
		if('unit' in window){
			was_error_on_unit_test = false;
			production = false;
			delete window.unit
			make_unit_tests();
		}
	},500);
	setInterval(function(){
		make_unit_tests(true);
	},5000)
	var ktbt_debug = function(){
		console.group('report ktvt')
		_log.map(function(log){
			console.log(log)
		})
		console.groupEnd('report ktvt')
		var profile = []
		for(var k in _profile){
			profile.push({name:k,time:_profile[k]})
		}
		profile = profile.sort(function(a,b){
			if(a.time == b.time) return 0
			return a.time < b.time ? 1 : -1
		})
		console.group('profile_modules')
		profile.map(function(item){
			console.log('"'+item.name+'" loads in '+item.time+'ms')
		})
		console.groupEnd('profile_modules')
	}
	var log = function(msg){
		var msglog = '+' + (new Date().getTime()-lasttime) + 'ms (+'+(new Date().getTime()-starttime)+'ms total) '+msg
		_log.push(msglog)
		if(report_logs) console.log(msglog)
		lasttime = new Date().getTime()
	}
	var prefix = '//js.ktbt.ru/precompiled'
	var ready_modules = {}
	var require_iframe = document.createElement('iframe')
	var iframe_ready = 0
	//require_iframe.style.display = 'none' //
	require_iframe.style.position = 'absolute'
	require_iframe.style.top = '-10400600px'
	require_iframe.style.visibillity = 'hidden'
	require_iframe.style.overflow = 'hidden'
	require_iframe.style.width = '1px'
	require_iframe.style.height = '1px'
	require_iframe.style.zIndex = '-2147483645'
	require_iframe.style.margin = '0'
	require_iframe.style.padding = '0'
	require_iframe.style.border = '0'
	
	log('starting require')
	
	require_iframe.onload = function(){
		log('master iframe onload')
		iframe_ready = 2
		start()
	}
	var require = function(module,callback){
		log('require modules "'+module.join(', ')+'" version '+version)
		//console.time('module '+module)
		var need_to_load = module.length
		var done = function(){
			//console.timeEnd('module '+module)
			if(typeof callback == 'undefined') {
				return
			}
			var args = []
			module.map(function(module){
				if(module.indexOf('/')==-1 || module[module.length-1]=='/')
					module+='/i'
				module = module.replace(/\/\//g,'/')
				var func = module.split(':')
				if(func.length>1){
					module= module.split(':')[0]
					func[1].split(',').map(function(func){
						args.push(ready_modules[module][func])
					})
				}
				else
					args.push(ready_modules[module])
			})
			log('module "'+module+'" ready, call callback')
			callback.apply(window,args)
		}
		
		module.map(function(module){
			module = module.split(':')[0]
			if(module.indexOf('/')==-1 || module[module.length-1]=='/')
				module+='/i'
			module = module.replace(/\/\//g,'/')
			if(module in ready_modules && ready_modules[module]!=null){
				if(--need_to_load==0) done()
				return
			}
			var check_for_module_ready = function(){
				if(module in ready_modules && ready_modules[module]===null){
					setTimeout(check_for_module_ready,30)
					return
				}
				else{
					if(--need_to_load==0) done()
					return
				}
			}
			if(module in ready_modules && ready_modules[module]===null){
				check_for_module_ready()
				return
			}
			ready_modules[module] = null
			_profile[module] = new Date().getTime()
			var iframe = document.createElement('iframe')
			//iframe.setAttribute('name',module)
			
			var iframe_onload = false
			iframe.onload = function(){
				if(iframe_onload) return
				iframe_onload = true
				iframe.contentWindow.onerror = function(errorMsg, url, lineNumber){
					// doesnt work on chrome...
					//http://code.google.com/p/chromium/issues/detail?id=159566
				}
				
				var onload = function(){
					var check_for_ready = function(){
						if(ready_modules[module]) {
							return
						}
						var exports = iframe.contentWindow.exports
						if(iframe.contentWindow._ready){
							ready_modules[module] = exports
							_profile[module] = new Date().getTime() - _profile[module]
							if(--need_to_load==0) {
								log('all modules done, call done()')
								done()
							}
						}
						else{
							log('module "'+module+'" not ready, waiting')
							setTimeout(check_for_ready,30)
						}
					}
					check_for_ready()
				}
				
				iframe.contentWindow.global = {
					require: require,
					window: window,
					thisSrc: thisSrc,
					version: version
				};
				iframe.contentWindow._callback = onload
				iframe.contentWindow.test = function(name,testfunc){
					unittests[module] = unittests[module] || {
						window: iframe.contentWindow,
						module: module,
						tests: []
					};
					unittests[module].tests = unittests[module].tests.filter(function(test){ return test[0]!=name });
					unittests[module].tests.push([name,testfunc]);
				};
				
				var script = document.createElement('script')
				script.src = document.location.protocol + prefix+'/'+module+'.js?v='+version
				script.setAttribute('charset','UTF-8')
				script.setAttribute('type','text/javascript')
				script.setAttribute('crossorigin','anonymous')
				script.setAttribute('async','async')
				script.onerror = function(err){
					log('error on loading module "'+module+'"')
				}
				script.onload = onload
				iframe.contentWindow.document.head.appendChild(script)
			}
			
			require_iframe.contentWindow.document.body.appendChild(iframe)
			
			if(!iframe_onload){
				var iframeDoc = iframe.contentDocument
				//bugfix for opera & firefox, они не тригерили onload на iframe
				iframeDoc.open()
				iframeDoc.write('<!doctype html><html><head></head><body></body></html>')
				iframeDoc.close()
			}
		})
		
	}
	
	var _init = false
	function start(){
		log('start()')
		if(_timeout) clearTimeout(_timeout)
		if(_init) return
		if(!document.body){
			_timeout = setTimeout(start,30)
			return
		}
		if(iframe_ready==0){
			iframe_ready = 1
			document.body.appendChild(require_iframe)
			_timeout = setTimeout(start,30)
			return 
		}
		if(iframe_ready==1){
			_timeout = setTimeout(start,30)
			return
		}
		if(iframe_ready==2 && (!require_iframe.contentDocument || !require_iframe.contentDocument.body || !require_iframe.contentDocument.head)){
			_timeout = setTimeout(start,30)
			return
		}
		log('require ready, start')
		_init = true
		require(['main_en/dcu','main/preload', 'main/guid', 'main/bind', 'main/timeout', 'main/style', 'main/store', 'main/kv', 'main/i18n', 'main/ping', 'main/activity_check', 'main_en']);
	}
})()
$(document).ready(function(){
		$('.menu-dostavka a').click(function(){
			$('.menu-dostavka a').removeClass('active');
			$(this).addClass('active');
			return false;
		});
});
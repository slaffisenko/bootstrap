var mistake;

function hide()
{
    var win = parent.document.getElementById('mistake');
    win.parentNode.removeChild(win);
    document.onkeypress = getText;
}

function sendMistake()
{
    var mform = document.getElementById("m_form");
    $.post('/tools/mistakes.html', {"url": document.location.href, "mistake": mistake, "comment": $("#mcomment").val(), "csrf": csrf},
        function()
        {
            mform.innerHTML = '<div class="thank">Спасибо!<br />Ваше сообщение отправлено.<br /><br /><br /><input onclick="hide()" type="button" value="Закрыть окно" name="close"></div>';
        }).error(function() { mform.innerHTML = '<div class="thank">Извините, произошла ошибка.</p><br /><br /><br /><input onclick="hide()" type="button" value="Закрыть окно" name="close"></div>';});
}

function createMessage()
{
    var container = document.createElement('div');
    container.setAttribute("id", "mistake");
    var scroll = 0; // document.documentElement.scrollTop || document.body.scrollTop;
    var mtop = scroll + 150 + 'px';
    var mleft = Math.floor(document.documentElement.clientWidth/2) - 175 + 'px';
    container.innerHTML = '<div id="m_window" style="top:' + mtop + '; left:' + mleft + '";><form name="mistake" onsubmit="return false;" method="post" id="m_form"><br />Ошибка:<br /><textarea name="mistake" rows="5" cols="25" class="marea" readonly="readonly">' + mistake + '</textarea><br />Комментарий:<br /><textarea name="comment" rows="5" cols="25" class="marea" id="mcomment"></textarea><br /><br /><button onclick="sendMistake()" class="btn" name="submit">Отправить</button> <button onclick="hide()" class="btn" name="close" >Отмена</button></form></div>';

    return container;
}

function winop()
{
    document.onkeypress = "";
    var messageElem = createMessage();
    messageElem.style.position = 'absolute';
    messageElem.style.height = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight, document.documentElement.clientHeight) + 'px';
    messageElem.style.width = Math.max(document.documentElement.scrollWidth, document.body.scrollWidth, document.documentElement.clientWidth) + 'px';
    document.body.appendChild(messageElem);
}


function getText(e)
{
    if (!e) e= window.event;
    if ((e.ctrlKey) && ((e.keyCode==10)||(e.keyCode==13))) {
        if (navigator.appName == 'Microsoft Internet Explorer') {
            if (document.selection.createRange()) {
                var range = document.selection.createRange();
                mistake = range.text;
            } else return false;
        } else {
            if (window.getSelection()) {
                mistake = window.getSelection();
            } else 	if (document.getSelection()) {
                mistake = document.getSelection();
            } else return false;
        }
        mistake = mistake.toString().replace(/^\s*/, "").replace(/\s*$/, "");
        if (mistake.length != 0) {
            winop();
            return true;
        }
    }
    return true;
}


document.onkeypress = getText;

﻿(function(a){
   var p = {};
	    
	      p['Step']         = 'Шаг';
	      p['Send']         = 'Отправить';
	      p['Start Chat']   = 'Начать чат';
	      p['Help online']  = 'Помощь онлайн';
	      p['Help offline'] = 'Оставить сообщение';
	      p['Ask operator'] = 'Спросить у оператора';
	      
	      //invite
	      p['Operator']        = 'Оператор';
	      p['Than I can help'] = 'Могу быть полезен?';
	      p['Yes please']      = 'Да';
	      p['No thanks']       = 'Нет';
	     

	      p['devision_select']         = 'Пожалуйста, выберите отдел';
	      p['type_contact_data']       = 'Для начала чата, пожалуйста представьтесь и напишите вопрос';
	      p['chat_begin']              = 'Начать чат';
	      p['offline_operator']        = 'Мы не в сети, пожалуйста, оставьте свое сообщение и контакты, мы с вами свяжемся!';
	      p['mes_done']                = 'Отправить';
	      p['thank_if_problem_solved'] = 'Спасибо за обращение!';
		  p['Thank_you']			   = 'Спасибо';
	      p['problem_resolved_ask']    = 'Довольны ли вы обслуживанием оператора?';
	      p['yes']                     = 'Да';
	      p['no']                      = 'Нет';
	      p['online_operator']         = 'Здравствуйте, чем могу Вам помочь?';  
	      p['problem_solved']          = ', решена';
	      p['problem_not_resolved']    = ', не решена';
	      p['send_email_dailogues']    = 'Отправка диалога на E-mail';
	      p['end']                     = 'Завершить';
	      p['pay']                     = 'Оплатить';
	      p['writing_text']            = 'печатает текст';
	      p['dialogue_sent_email']     = 'Диалог отправлен на ';
	      p['thank_you_email']         = 'Спасибо, Ваше сообщение было отправлено!';
	      p['enter_correct_email']     = 'Введите верный E-mail';
	      p['enter_correct_message']   = 'Введите текст сообщения';
	      p['sound_off']               = 'Звук выключен';
	      p['sound_on']                = 'Звук включен';
	      p['video_chat']              = 'Видео чат';
	      p['talk_to_operator']        = 'Поговорить с оператором';
	      p['attach_file']             = 'Прикрепить файл';
	      p['enter_text_and_enter']    = 'Введите текст и нажмите Enter';
	      p['enter_message']           = 'Введите сообщение';
	      p['your_name']               = 'Ваше имя';
	      p['save_and_exit']           = 'Сохранить и Выйти';
	      p['enter_required_fields']   = 'Вы заполнили не все поля';
	      p['You']                     = 'Вы';
	      p['Back']                    = 'Назад';
	      p['Phone']                   = 'Телефон';
	      
	      // services
	      p['connecting_to_server'] = 'Подключение к серверу';
	      p['waiting_message']      = 'Соeдинение с оператором';
	      p['online_operator']      = 'Здравствуйте, чем могу Вам помочь?';
	      
	      
	      p['The dialogue is completed'] = 'Диалог завершен';
	      
	      p['hypertext_more']          = 'Подробнее...';
	      
	      p['Invoice paid'] = 'Счет оплачен';
		  
		  
		  p['pay_data']				= 'Платежные данные:';
		  p['pay_email']			= 'Ваш E-mail';
		  p['pay_title']			= 'Назначение платежа';
		  p['pay_price']			= 'Сумма оплаты';
		  p['pay_comment']			= 'Ваш комментарий';
		  p['pay_pay']				= 'Оплатить';
		  p['enter_correct_title']	= 'Введите верное назначение платежа';
		  p['enter_correct_price']	= 'Введите верную сумму';
		  p['pay_error']			= 'Произошла ошибка, попробуйте позже.';
		  p['pay_send']				= 'Для перевода';
		  p['pay_enter']			= 'перейдите по ссылке:';
		  p['pay_do']				= 'Сделать платеж';
		  
		  
		  p['exit_phone']			= 'Ваш номер телефона';
		  p['exit_thank']			= 'Спасибо за обращение.';
		  p['exit_solution']		= 'Ваша проблема будет рассмотрена нашими сотрудниками в ближайшее время.';
		  p['enter_correct_phone']	= 'Введите правильный номер телефона.';
		  p['enter_correct_requisits']	= 'Введите телефон и/или E-mail';
		  
		  p['get_contacts']	= 'Оставьте, пожалуйста, свои контактные данные и мы свяжемся с вами.';
		  p['send_to_email']	= 'Диалог будет отправлен на ваш E-mail';
		  
		  p['offline_dear_customer']	= 'Уважаемый клиент!';
		  p['offline_dear_description']	= 'Если Вы не получили ответ на Ваш вопрос, Вы можете заполнить форму и с Вами свяжется наш специалист для решения Вашего вопроса.';
		  
		  p['paychat_capt']	= 'Доверенный предприниматель';
		  p['paychat_text']	= 'В этом чате вы можете оплатить покупку картами VISA/MasterCard.';
		  
		  p['track_widget_count']	= 'Количество посетителей на сайте';
		  
		  p['faq_start_chat']		= 'Начать чат';
		  p['faq_leave_message']	= 'Оставить сообщение';
		  p['faq_more']				= 'Подробнее';
		  p['faq_answer_vote']		= 'Ответ полезен';
		  p['faq_additional_questions'] = 'Смотри также';
		  p['Enter your question'] = 'Введите Ваш вопрос';

		  p['Thanks for your question'] = 'Спасибо за Ваш вопрос';
		  
		  
		  
		  
	        
	  
	  
	      a._=function(keyName,params){if(!(keyName in p))return keyName;var template=p[keyName];if(!params)params={};return template.replace(/\{([\w\.]*)\}/g,function(str,key){var keys=key.split(".");key=keys.shift();if(key in params)var value=params[key];else value="";for(var i=0;i<keys.length;i++)value=value[keys[i]];return value===null||value===undefined?"":value})};
	  
	      a._get = function(keyName){ if(!keyName) return p; return p[keyName];};
	      
	      a._set = function(k,v){return p[k]=v;};
	   
})(SH);
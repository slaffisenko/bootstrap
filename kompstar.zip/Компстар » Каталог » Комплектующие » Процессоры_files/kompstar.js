function blockWidth() {
    var cellWidth = $('.make-order .order .gen-info').width();
    var imgWidth = $('.make-order .order .img').width();

    var widthWin = $(window).width();
    var leftedWidthActive = cellWidth + imgWidth + 10;
    var leftedWidth = cellWidth + 62;

    $('.order-info .lefted').width(leftedWidth);

    //alert(widthWin);

    if (widthWin > 900 && widthWin < 1280 && $('.wide-hide').is(':visible')) {
        leftedWidthActive = 310;
    }

    $('.order-info .lefted-active').width(leftedWidthActive);

}

function cw(url, n, w, h, s) {
	var l = parseInt(screen.width / 2 - w / 2), t = parseInt(screen.height / 2 - h / 2);
    var o = "width=" + w + ",height=" + h + ",left=" + l + ",top=" + t + ",screenX=" + l + ",screenY=" + t + ",resizable=0,toolbar=0,location=0,status=0,menubar=0,directories=0" + (s ? ",scrollbars=" + s : "");
    var q = window.open(null, n, o);
    if(q.location.href.indexOf(url) < 0){
        q.location.href = url;
    }
	try {
        q.focus();
    } catch(e) {}
	return false;
}

function contentHight() {
    var r = function() {
        $('#ContentDiv').css('min-height', $('#SidebarDiv').height());
    };
    r(); setTimeout(r, 100);
}

function compareWidth() {

    $('.compare-wrapper').each(function() {
        var compareWrapper = $(this).width();
        var compareWidth = $('.compare-items').width();
        if (compareWrapper < compareWidth) {
            $(this).css({'overflow-x': 'scroll'});
        }
    });
}

function bindNotes() {
    var Changed = false;
    var textArea = $("#textAreaNote textarea");
    textArea.change(function() {
        console.log('Notes changed');
        Changed = true;
        SaveNotes();
    });
    var LoadNotes = function() {
        $.get('/tools/mynotes.html', function(Data) {
            console.log('Notes loaded');
            textArea.val(Data);
        });
    };
    var SaveNotes = function() {
        if (Changed) {
            var Data = textArea.val();
            Changed = false;
            $.post('/tools/mynotes.html', {'csrf': csrf, 'Data': Data}, function(r) {
                        console.log('Notes saved');
                    });
        }
    };
    setInterval(SaveNotes, 500);
    $(window).unload(SaveNotes);
    LoadNotes();
}

function Declination(c, Form) {
    var mod100 = c%100;
    switch (c%10) {
        case 1:
            if (mod100 == 11)
                return Form[2];
            else
                return Form[0];
        case 2:
        case 3:
        case 4:
            if ((mod100 > 10) && (mod100 < 20))
                return Form[2];
            else
                return Form[1];
        case 5:
        case 6:
        case 7:
        case 8:
        case 9:
        case 0:
            return Form[2];
    }
    return '';
}
var FilterRange = function() {

    if(!$("#SearchFilterForm").length) {
        return;
    }

    var qPrice = $("#fPrice");
    var qPriceRange = $('#fPriceRange', qPrice);

    var qPriceRange_min = $('#fPriceRange-min', qPrice);
    var qPriceRange_max = $('#fPriceRange-max', qPrice);

    var Min = parseFloat(qPriceRange.attr('min'));
    var Max = parseFloat(qPriceRange.attr('max'));
    var vMin = parseFloat(qPriceRange_min.val());
    var vMax = parseFloat(qPriceRange_max.val());

    Min = (Min - 10 > 0) ? (Min - 10) : Min;
    Max = Max + 10;
    
    vMin = (vMin - 10 > 0) ? (vMin - 10) : vMin;
    vMax = vMax + 10;

    var qPriceSelectionSet = function(Min, Max) {
        qPriceRange.range('set', [Min, Max]);
        qPriceRange_min.val(Min);
        qPriceRange_max.val(Max);
    };

    var qPriceSelectionASet = function() {
        var vMin = parseFloat(qPriceRange_min.val());
        var vMax = parseFloat(qPriceRange_max.val());

        if (vMin < Min) {
            vMin = Min;
        }
        if (vMax > Max) {
            vMax = Max;
        }

        if (vMin > vMax) {
            vMax = vMin + 100;
        }

        qPriceRange.attr('data-min', vMin);
        qPriceRange.attr('data-max', vMax);

        qPriceRange.attr('data-break', true);
        qPriceRange.range('set', [vMin, vMax]);
        qPriceRange.removeAttr('data-break');
    };

    qPriceRange_min.blur(qPriceSelectionASet);
    qPriceRange_max.blur(qPriceSelectionASet);

    var qPriceRangeSet = function() {

        if (qPriceRange.data('TinyRange')) {
            qPriceRange.range('destroy');
        }

        var Avg = Math.ceil((Max + Min) / 2);

        $('#left-range', qPrice).text(Min);
        $('#middle-range', qPrice).text(Avg);
        $('#right-range', qPrice).text(Max);


        qPriceRange.attr('value', Avg).val(Avg);

        var rangeChanged = function() {
            var Max = qPriceRange.attr('data-max') * 1;
            var Min = qPriceRange.attr('data-min') * 1;
            qPriceRange_min.val(Min).change();
            qPriceRange_max.val(Max).change();
        };

        qPriceRange.attr({'min': Min, 'max': Max});
        qPriceRange.range({'min': Min, 'max': Max, change: rangeChanged});
        qPriceSelectionSet(Min, Max);
    };

    qPriceRangeSet();
    qPriceSelectionSet(vMin, vMax);

    FilterShippingRange();
    qSearchPreResult();
    
    $('a.collapselink').on('click', function(){
        var rel = $(this).attr('rel');
        $("#" + rel).toggleClass('none');
        return false;
    });
    $('a.expandlink').on('click', function(){
        var rel = $(this).attr('rel');
        $("#" + rel).toggleClass('min');
        return false;
    });

};

var FilterShippingRange = function() {
    var Element = $( "#ShippingRange" );
    var Range = Element.attr('data-values').split(';');
    var Rel = $("#"+ Element.attr('rel') );
    var Input = $("#"+ Element.attr('data-input') );
    Element.slider({
        range: "min",
        value: Element.attr('data-value'),
        min: Element.attr('data-min'),
        max: Element.attr('data-max'),
        slide: function( event, ui ) {
            Rel.html( Range[ ui.value ] ? Range[ ui.value ] : '' );
            Input.val(ui.value).change();
        }
    });
    var Value = Element.slider( "value" );
    Rel.html( Range[ Value ] ? Range[ Value ] : '' );
    Input.val(Value);
};

var qSearchPreResult = function() {
    var PreResult = $("#PreResult");
    var SearchFilterForm = $("#SearchFilterForm");
    var Link = $('a', PreResult);
    var Counter = $('span', PreResult);
    var Units = Counter.attr('data-units').split(',');
    var cb = null, ht = null;
    $('input, select', SearchFilterForm).change(function(e){
        var Top = (Mouse.y - 100);
        cb && clearTimeout(cb);
        cb = setTimeout(function(){
            $.get('/tools/qsearch.html', SearchFilterForm.serialize(), function(Count) {
                Count = parseInt(Count);
                if(Count > 0) {
                    Link.show();
                } else {
                    Link.hide();
                }
                Counter.html(Count + ' ' + Declination(Count, Units));
                PreResult.css('top', Top + 'px').removeClass('none').show();
                ht && clearTimeout(ht);
                ht = setTimeout(function(){
                    PreResult.fadeOut();
                }, 6000);
            });
        }, 700);
    });
};

var catalogListItemsInit = function() {
    $('a.addToCompare, a.removeFromCompare').unbind('click').on('click', function() {
        var a = $(this);
        var url = a.attr('href');
        url = url.substring(url.indexOf('?'));
        $("#CompareBlock").loadJFrame('/compare/widget/' + url);
        /*var block = a.parentsUntil('.item-block').parent();
         if(block.hasClass('Compared')) {
             block.addClass('noneCompared');
             block.removeClass('Compared');
         } else {
             block.addClass('Compared');
             block.removeClass('noneCompared');
         }*/
        return false;
    });
    $('a.addToCart').unbind('click').on('click', function() {
        var a = $(this);
        var url = a.attr('href');
        url = url.substring(url.indexOf('?'));
        $("#BasketBlock").loadJFrame('/order/widget/' + url);
        return false;
    });
};

var catalogInfScroll = {
    PageNumber: 1,
    MaxPageNumber: 3,
    Loading: false,
    wnd: null,
    wndH: null,
    top: null,
    div: null,

    url: (function(){
        var url = location.href;
        url = url.replace('/catalog/', '/catalog/items/');
        url = url.replace(/([\?&])p=([0-9]+)/, '$1');
        return url;
    })(),

    setLoader: function(Loading) {
        catalogInfScroll.Loading = Loading;
        if(Loading) {
            catalogInfScroll.div.addClass('Loader');
        } else {
            catalogInfScroll.div.removeClass('Loader');
        }
    },

    getPage: function(div, url) {
        catalogInfScroll.setLoader(true);
        $.get(url, function(html){
            div.append(html);
            setTimeout(function(){
                catalogListItemsInit();
                catalogInfScroll.setLoader(false);
                catalogInfScroll.Scroll();
            }, 1000);
        });
    },

    Scroll: function(){
        if(catalogInfScroll.Loading) {
            return null;
        }

        var t = catalogInfScroll;

        var itop = t.div.find('.catalog-item:last').offset().top;
        var url = t.url;

        if  (t.wnd.scrollTop() >  itop - t.top - 300 && !(t.PageNumber >= t.MaxPageNumber)){
            t.PageNumber++;
            var _url = url + (url.indexOf('?') > 0 ? '&' : '?') + 'p=' + t.PageNumber;
            t.getPage(t.div, _url);
            $('.paginator .p-' + t.PageNumber).addClass('page-loaded');
        }
        return null;
    },

    Init: function() {
        var div = $("#catalog-item-wrapper");
        var url = catalogInfScroll.url;
        if(div.length > 0 && url.indexOf('/catalog/') > 0) {
            catalogInfScroll.div = div;
            catalogInfScroll.wnd = $(window);
            catalogInfScroll.wndH = catalogInfScroll.wnd.height();
            catalogInfScroll.top = div.offset().top;
            catalogInfScroll.wnd.scroll(catalogInfScroll.Scroll);
        }
    }
};

var Mouse = {x: -1000, y: -100};

$(window).load(contentHight);
$(document).ready(function() {

    if(location.href.indexOf('p=All') > 0) {
        catalogInfScroll.Init();
    }

    $(document).mousemove(function(e) {
        Mouse.x = e.pageX;
        Mouse.y = e.pageY;
    });

    if(window != window.top) {
        var top = window.top.document;
        top.getElementsByTagName('body')[0].setAttribute('style', 'margin: 0 !important; padding: 0 !important; overflow: hidden !important;');
        top.getElementsByTagName('iframe')[1].setAttribute('style', 'z-index: 9998; width: 100%; height: 100%; position: absolute; top: 0px; left: 0px; border: 0px none; background-color: rgb(255, 255, 255);');
    }

    compareWidth();
    contentHight();
    setInterval(contentHight, 100);

    Cufon.replace('p.phone');
    Cufon.replace('.cufon');

    bindNotes();

    $(".nav li ul li a").click(function(event) {
        event.preventDefault();
    });

    $('#goup').click(function(e) {
        e.preventDefault();
        $('div#menu-second-level').slideUp('100');
    });
    $('#Contacts a.mailMe').click(function() {
        var a = $(this);
        var id = a.attr('data-id');
        var to = $("#Contact-" + id + ' li:first').text();
        $("#mailMeToName").text(to);
        $("#mailMeToId").val(id);
    });

    /*$("#callMeForm").submit(function() {
        var Form = $(this), Wnd = Form.parent(), callMePhone = $("#callMePhone").val(), Inputs = Form.find('input, select, button');
        Inputs.attr('disabled', true);
        $.post('/tools/callme.php', {Phone: callMePhone}, function(data) {
                    if (data == 'ok') {
                        Form.hide();
                        Wnd.find('.ok').removeClass('none').show();
                        Wnd.find('.err').hide();
                    } else {
                        Wnd.find('.ok').hide();
                        Wnd.find('.err').removeClass('none').show();
                    }
                    Inputs.removeAttr('disabled');
                });
        return false;
    });*/

    $('#catalog-main a.dropdown-toggle').click(function(e) {
        var c = $('#menu-container');
        var c2 = $('#menu-second-level');
        $.get('/tools/catalogMenu.html', function(html) {
            c.html(html).show().slideDown('100');
            $('a', c).click(function(e) {
                e.preventDefault();
                e.stopPropagation();
                $("a", c).removeClass('active');
                $(this).addClass('active');
                c2.slideUp('100');
                $.get('/tools/catalogMenu.html?PID=' + $(this).attr('rel'), function(html) {
                    c2.html(html).show().slideDown('100');
                    var o = c2.offset();
                    if($(document).scrollTop() > o.top) {
                        $(document).scrollTop(c.offset().top);
                    }
                    $('#menu-container .container-fluid').hide();
                });
            });
        });
        $('#menu-second-level').hide();
        $('#menu-container .container-fluid').show();
    });

    $('#info-parts a.dropdown-toggle').click(function() {
        var ip = $('#info-parts').hasClass('open');
        $('#info-menu').toggle(!ip);
    });

    if ($(".fresh-goods").length > 0) {
        var blockOItem = $("#ContentDiv .fresh-goods li:eq(0)");
        var calculateMainItems = function(div) {
            return Math.floor(div.width() / blockOItem.width());
        };
        var wrapMainItems = function(div) {
            var i = calculateMainItems(div);
            div.find('li:lt(' + i + ')').show();
            div.find('li:gt(' + ( i - 1) + ')').hide();
        };
        var watchMainItems = function() {
            wrapMainItems($("#NewItems"));
            wrapMainItems($("#LastPurchasedItems"));
            wrapMainItems($("#catalogArticles"));
        };
        $(window).resize(watchMainItems);
        watchMainItems();
    }


    $('#slideUp').click(function() {
        var txt = $('#seen-goods-fhoto').is(':visible') ? 'Развернуть' : 'Свернуть';
        $('#seen-goods-fhoto').slideToggle('fast');
        $(this).text(txt).toggleClass('down');
        return false;
    });

    var catalogGridToggle = function(e) {
        var a = $('.catalog-grid');
        if (e) {
            $.jStorage.set('ItemListType', !a.hasClass('row-grid') ? 'row' : 'grid');
        }
        var flag = !($.jStorage && $.jStorage.get('ItemListType') == 'row');
        var txt = flag ? 'Выводить товары сеткой' : 'Выводить товары рядами';
        if (flag) {
            $('#catalog-item-wrapper').removeClass('grid');
            a.text(txt).removeClass('row-grid');
        } else {
            $('#catalog-item-wrapper').addClass('grid');
            a.text(txt).addClass('row-grid');
        }
        contentHight();
        return false;
    };

    $('.catalog-grid').click(catalogGridToggle);
    catalogGridToggle(false);

    $('.good-charachter tr:odd').css("background-color", "#f0f0f0").last().css("background-color", "#ffffff");

    /****************************************************************************/
    $('.goods-info-block').each(function(i, g){
        var b = $('.sale-list', g);
        if(i) { b.hide(); }
        var v = b.is(':visible');
        var txt = v ? 'Свернуть' : 'Развернуть';
        var a = $('a.toggle-link', g);
        if(v) {
            a.addClass('down').text(txt);
        } else {
            a.removeClass('down').text(txt);
        }
    });


    $('.toggle-link').click(function() {
        var block = $(this).parents('.order-info').next('.sale-list');
        var txt = block.is(':visible') ? 'Развернуть' : 'Свернуть';
        block.slideToggle('fast');
        $(this).text(txt).toggleClass('down');
        return false;
    });
    /****************************************************************************/

    $('#goup-info').click(function() {
        $('#info-menu').parents('.dropdown').removeClass('open');
    });

    /****************************************************************************/
    $('#goup-level2').on("click", function(e) {
        $('#menu-second-level').hide();
        $('#menu-container a').removeClass('active');
        $('#menu-container .container-fluid').show();
    });

    $('#goup-catalog').on("click", function(e) {
        $('#menu-container').parents('.dropdown').removeClass('open');
        $('#menu-container .container-fluid').show();
    });

    $('#menu-container').on("click", function(e) {
        $('#menu-second-level').hide();
        $('#menu-container a').removeClass('active');
        $('#menu-container .container-fluid').show();
    });
    /****************************************************************************/

    blockWidth();

    $(window).resize(function() {
        blockWidth();
        contentHight();
        compareWidth();
    });

    $("html").ajaxComplete(function(event, request, settings) {
        contentHight();
    });

    /*var seenGoods = $('.seen-goods div#seen-goods-fhoto > div');
    seenGoods.hover(
            function () {
                $('.descr').hide();
                $(this).find('div.descr').show();
            },
            function () {
                $('.descr').hide();
            }
    );*/

    /*$('div.descr').hover(
            function() {
                $(this).hide();
            },
            function() {
                $(this).hide();
            }
    );*/


    //$('#myModal').modal('show')
    //$('#modalRef').modal('show')
    //$('#lessPrice').modal('show')

    $("form.ajax").submit(function() {
        var form = $(this);
        var action = form.attr('action') || location.href;
        var container = form.parent();
        var data = form.serialize();
        var controls = $('input, button, select', form);
        controls.attr('disabled', true);
        var success = form.attr('data-success') || null;
        $.post(action, data, function(response) {
            switch (response) {
                case 'ok':
                    $('.ok', container).removeClass('none').show();
                    $('.err', container).hide();
                    form.hide();
                    eval(success);
                    break;
                case 'err':
                default:
                    $('.err', container).removeClass('none').show();
                    $('.ok', container).hide();
                    form.show();
                    break;
            }
            controls.removeAttr('disabled');
        });
        return false;
    });

    catalogListItemsInit();

    var qGroupInit = function() {
        var qGroup = $("#qGroup");
        var qForm = qGroup.parentsUntil('form').parent();
        var qBrand = $("#qBrand");
        var qPrice = $("#qPrice");
        var qPriceRange = $('#qPriceRange', qPrice);
        var setPrice = function(GID, BID) {
            $.getScript('/tools/qnav.html?GID=' + GID + '&BID=' + BID, function() {
                var Min = qPriceData.Min / 1, Max = qPriceData.Max / 1;
                if(Min > 0 && Max > 0) {
                    Min = (Min - 10 > 0) ? (Min - 10) : Min;
                    Max = Max + 10;
                    if (Min != Max) {
                        $('input', qPrice).removeAttr('disabled');
                        qPriceRangeSet(Min, Max);
                        qPrice.find('.qPriceInput').show();
                    } else {
                        $('input', qPrice).attr('disabled', true);
                        qPrice.find('.qPriceInput').hide();
                    }
                } else {
                    qPriceRangeSet(0, 0);
                    $('input', qPrice).attr('disabled', true);
                    qPrice.find('.qPriceInput').hide();
                }
            });
            qPrice.removeClass('none').show();
        };

        var qPriceSelectionSet = function(Min, Max) {
            qPriceRange.range('set', [Min, Max]);
            $('#qPriceRange-min', qPrice).val(Min);
            $('#qPriceRange-max', qPrice).val(Max);
        };

        var qPriceRangeSet = function(Min, Max) {

            if (qPriceRange.data('TinyRange')) {
                qPriceRange.range('destroy');
            }

            var Avg = Math.ceil((Max + Min) / 2);

            $('#left-range', qPrice).text(Min);
            $('#middle-range', qPrice).text(Avg);
            $('#right-range', qPrice).text(Max);


            qPriceRange.attr('value', Avg).val(Avg);

            var rangeChanged = function() {
                var Max = $('#qPriceRange', qPrice).attr('data-max') * 1;
                var Min = $('#qPriceRange', qPrice).attr('data-min') * 1;
                $('#qPriceRange-min', qPrice).val(Min);
                $('#qPriceRange-max', qPrice).val(Max);
                $('#left-range', qPrice).text(Min);
                $('#right-range', qPrice).text(Max);
            };

            qPriceRange.attr({'min': Min, 'max': Max});
            qPriceRange.range({'min': Min, 'max': Max, change: rangeChanged});
            qPriceSelectionSet(Min, Max);
        };

        if (qGroup.attr('rel') != 'loaded') {

            console.log('qGroup loaded');

            qGroup.attr('rel', 'loaded');
            $.get('/tools/qnav.html', function(data) {
                qGroup.html(data);
                qGroup.change(function() {
                    var GID = qGroup.val();
                    var Link = $('option:selected', qGroup).attr('rel');
                    if (GID > 0) {
                        qForm.attr('action', Link);
                        $.get('/tools/qnav.html?GID=' + GID, function(data) {
                            qBrand.html(data).removeClass('none').show();
                            qBrand.change(function() {
                                setPrice(GID, qBrand.val());
                            });
                            setPrice(GID, 0);
                        });
                    } else {
                        qForm.attr('action', '.');
                        qBrand.hide();
                        qPrice.hide();
                    }
                });
            });
        }
    };
    
    $("#qGroup").bind('hover click focus', qGroupInit); setTimeout(qGroupInit, 300);

    $('a.collapselink').on('click', function(){
        var rel = $(this).attr('rel');
        $("#" + rel).toggleClass('none');
        return false;
    });
    
    $("#SearchInput").autocomplete({
        delay: 0,
        minLength: 3,
        source: "/tools/autocomplete.html?GID=" + $("#SearchInput").attr('data-gid')
    });
});


function CompareReload(count, list) {
    list = list || [];

    var block = $('.item-block');
    block.addClass('noneCompared');
    block.removeClass('Compared');

    if (count != 0) {
        $("#CompareCounter").removeClass('none').show().html(count);
        $.each(list, function(i, id) {
            var block = $('#Item-' + id + '.item-block');
            block.addClass('Compared');
            block.removeClass('noneCompared');
        });
    }
    else {
        $("#CompareCounter").hide();
    }
}

function BasketReload(count, list) {
    list = list || [];

    var block = $('.item-block');
    block.removeClass('inCart Price Price1 Price3 Price7');

    if (count > 0) {
        $("#OrderCounter").removeClass('none').show().html(count);
        $.each(list, function(id, Prices) {
            var block = $('#Item-' + id + '.item-block');
            block.addClass('inCart').addClass(Prices.join(' '));
        });
    }
    else {
        $("#OrderCounter").hide();
    }
}


/*******************************************************************************************/
function number_format(number, decimals, dec_point, thousands_sep) {  // Format a number with grouped thousands
    //
    // +   original by: Jonas Raoni Soares Silva (http://www.jsfromhell.com)
    // +   improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +     bugfix by: Michael White (http://crestidg.com)

    var i, j, kw, kd, km;

    // input sanitation & defaults
    if (isNaN(decimals = Math.abs(decimals))) {
        decimals = 2;
    }
    if (dec_point == undefined) {
        dec_point = ",";
    }
    if (thousands_sep == undefined) {
        thousands_sep = ".";
    }

    i = parseInt(number = (+number || 0).toFixed(decimals)) + "";

    if ((j = i.length) > 3) {
        j = j % 3;
    } else {
        j = 0;
    }

    km = (j ? i.substr(0, j) + thousands_sep : "");
    kw = i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands_sep);
    //kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).slice(2) : "");
    kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).replace(/-/, 0).slice(2) : "");
    return km + kw + kd;
}

var Cart = {
    init: function() {
        this.WidgetDiv = $("#BasketBlock");
        this.OrderListDiv = $("#OrderItemsList");
        this.WidgetDiv.click(function() {
            Cart.Reload.apply(Cart);
        });
    },
    Add: function(ItemID, Price, Count) {
        Count = Count || 1;
        Price = Price || 'Price';
        this.ReloadWidget('?event[ksUser]=Cart&ksUser[Cart][Price]=' + Price + '&ksUser[Cart][Add]=' + ItemID);
    },
    Reload: function() {
        this.ReloadWidget();
        this.ReloadOrderList();
    },
    ReloadWidget: function(url) {
        url = url || '';
        this.WidgetDiv.loadJFrame('/order/widget/' + url);
    },
    ReloadOrderList: function(url) {
        url = url || '';
        this.OrderListDiv.loadJFrame('/order/list/' + url);
        if (url) { // if doing some actions (add/delete items)
            this.ReloadWidget();
        }
    },
    BindOrderList: function() {
        this.OrderListDiv.find(".OrderItemBlock")
                .each(function(i, Item) {
                    Item = $(Item);
                    var ID = parseInt(Item.find("select").attr("rel"));
                    Item.find('select')
                            .live("change",
                            function() {
                                return Cart.CalcOrderListSetItemPrice.apply(Cart, [this, Item]);
                            });
                    Item.find('option:disabled')
                            .hover(
                            function() {
                                var Period = $(this).attr("value");
                                var target = $("#" + Period + "-" + ID);
                                target.css("background", "#33ff33");
                            },
                            function() {
                                var Period = $(this).attr("value");
                                var target = $("#" + Period + "-" + ID);
                                target.css("background", "none");
                            }
                    );
                });
        this.ReloadWidget();
    },
    CalcOrderListSetItemPrice: function(SelectObj, ItemObj) {
        SelectObj = $(SelectObj);
        ItemObj = $(ItemObj);
        var lval = SelectObj.attr("data-value");
        var val = SelectObj.val();
        if (lval != val) {
            var ID = parseInt(SelectObj.attr("rel"));
            this.ReloadOrderList('?event[ksUser]=Cart&ksUser[Cart][ChangePrice]=' + ID + '&ksUser[Cart][Price]=' + lval + '&ksUser[Cart][newPrice]=' + val);
        }
    }
};
/*******************************************************************************************/